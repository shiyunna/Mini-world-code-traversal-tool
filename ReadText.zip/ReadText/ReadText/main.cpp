#include "ReadText.h"
#include <QtWidgets/QApplication>
#include <QApplication>
#include<QMoveEvent>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ReadText w;
    w.show();
    return a.exec();
}
void ReadText::mousePressEvent(QMouseEvent *event)
{
	this->windowPos = this->pos();       // ��ò�����ǰλ��
	this->mousePos = event->globalPos(); // ������λ��
	this->dPos = mousePos - windowPos;   // �ƶ��󲿼����ڵ�λ��
}
 
void ReadText::mouseMoveEvent(QMouseEvent *event)
{
	this->move(event->globalPos() - this->dPos);
}
