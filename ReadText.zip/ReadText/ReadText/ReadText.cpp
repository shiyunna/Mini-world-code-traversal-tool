#include "ReadText.h"

#include <QDebug>
#include "Memory.h"
#include <QMovie>
#include <QTime>
#include <QComboBox>
#include <QMessageBox>
#include <QFile>
#include <qstandardpaths.h>

memory Memory;


DWORD PID;
DWORD module_address;
DWORD Itemaddr;
DWORD Biologyaddr;
DWORD Modeladdr;
DWORD ThrowAddr;
HWND g_gamehwnd = FindWindowA("RenderWindow_ClassName", NULL);




ReadText::ReadText(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);
    setWindowFlags(Qt::WindowType::FramelessWindowHint);
    setAttribute(Qt::WA_TranslucentBackground);

    ui.flycheck->setStyleSheet("QCheckBox::indicator{width:20px;height:20px;}\
            QCheckBox::indicator:unchecked{image:url(:/ReadText/R-C2 (1).png);}\
            QCheckBox::indicator:checked{image:url(:/ReadText/314.png);}");

    ui.Creaturecheck->setStyleSheet("QCheckBox::indicator{width:20px;height:20px;}\
            QCheckBox::indicator:unchecked{image:url(:/ReadText/R-C2 (1).png);}\
            QCheckBox::indicator:checked{image:url(:/ReadText/314.png);}");
    ui.Throwcheck->setStyleSheet("QCheckBox::indicator{width:20px;height:20px;}\
            QCheckBox::indicator:unchecked{image:url(:/ReadText/R-C2 (1).png);}\
            QCheckBox::indicator:checked{image:url(:/ReadText/314.png);}");
    ui.Itemcheck->setStyleSheet("QCheckBox::indicator{width:20px;height:20px;}\
            QCheckBox::indicator:unchecked{image:url(:/ReadText/R-C2 (1).png);}\
            QCheckBox::indicator:checked{image:url(:/ReadText/314.png);}");
    qDebug() << g_gamehwnd;
    if(g_gamehwnd == 0)
    {
        MessageBoxA(NULL, "����δ��", "error", MB_OK);
        exit(0);
    }
    connect
    (
        ui.pushButton_8,//����1
        SIGNAL(clicked(bool)),//����1�źţ��̶��ĺ����Ͳ���
        this,//����2
        SLOT(ShowItem(bool))//����2�Ĳۺ������Զ���ĺ���
 

    );
    connect
    (
        ui.pushButton_9,
        SIGNAL(clicked(bool)),
        this,
        SLOT(ShowCreature(bool))
    );
    connect
    (
        ui.pushButton_10,
        SIGNAL(clicked(bool)),
        this,
        SLOT(ShowSkin(bool))
    );
    connect
    (
        ui.pushButton_11,
        SIGNAL(clicked(bool)),
        this,
        SLOT(ShowThrow(bool))
    );

    GetData();

}
void GetData()
{
    GetWindowThreadProcessId(g_gamehwnd, &PID);
    Memory.InitProcessHandleForWindow("RenderWindow_ClassName", NULL);
    HANDLE hpro = Memory.GetProcessHandle();
    module_address = Memory.GetModuleAddress((char*)"libiworld_micro.dll");

    DWORD SkinFreeAddress = Memory.GetAddress((char*)"A1 ?? ?? ?? ?? 85 C0 75 ?? 6A 14 E8 ?? ?? ?? 01 8B F0 83 C4 04 89 75 F0 C7 45 FC 00 00 00 00 85 F6 74 ?? 8B CE E8 ?? ?? ?? FF C7 06 ?? ?? ?? ?? C7 46 08 00 00 00 00 C7 46 0C 00 00 00 00 C7 46 10 00 00 00 00 EB ?? 33 F6 89 35 ?? ?? ?? ?? 8B C6 8B 4D F4 64 89 0D 00 00 00 00 59 5E 8B E5 5D C3 CC CC CC CC CC CC CC CC CC CC CC B8 ?? ?? ?? ?? C3 CC CC CC CC CC CC CC CC CC CC 55 8B EC 6A", module_address, 0);
    QString ModelFree = Memory.GetFreeAddress(SkinFreeAddress);
    bool one;
    Modeladdr = ModelFree.toInt(&one, 16);

    DWORD ItemFreeAddress = Memory.GetAddress((char*)"89 3D ?? ?? ?? ?? 8B C7 8B 4D F4 64 89 0D 00 00 00 00 59 5F 5E 8B E5 5D C3 CC CC CC CC CC CC CC 55 8B EC 56", module_address, 0);
    QString ItemFree = Memory.GetFreeAddress(ItemFreeAddress + 1);
    bool two;
    Itemaddr = ItemFree.toInt(&two, 16);

    DWORD BiologyFreeAddress = Memory.GetAddress((char*)"89 1D ?? ?? ?? ?? 8B C3 8B 4D F4 64 89 0D 00 00 00 00 59 5F 5E 5B 8B E5 5D C3 CC CC CC CC CC CC 56", module_address, 0);
    QString BiologyFree = Memory.GetFreeAddress(BiologyFreeAddress + 1);
    bool three;
    Biologyaddr = BiologyFree.toInt(&three, 16);

    DWORD ThrowFreeAddress = Memory.GetAddress((char*)"89 1D ?? ?? ?? ?? 8B C3 8B 4D F4 64 89 0D 00 00 00 00 59 5F 5E 5B 8B E5 5D C3 CC CC CC CC CC CC B8 ?? ?? ?? ?? C3 CC CC CC CC CC CC CC CC CC CC 55 8B EC 6A FF 68 ?? ?? ?? ?? 64 A1 00 00 00 00 50 81", module_address, 0);
    QString ThrowFree = Memory.GetFreeAddress(ThrowFreeAddress + 1);
    bool Four;
    ThrowAddr = ThrowFree.toInt(&Four, 16);

 }
ReadText::~ReadText()
{
    

}


int ReadText::ShowItem(bool checked)
{
    QString number = ui.ItemLine->text();
    int value = number.toInt();
    QString str = "";

    for (int i = 1; i <= value; i++)
    {


        DWORD addr = Memory.Linked_Integer3(Itemaddr, 8, i * 4, 0x50);
        DWORD addr2 = Memory.Linked_Integer3(Itemaddr, 8, i * 4, 0);
        QString itemname = Memory.ReadMemoryString(addr);
        QString itemID = QString::number(Memory.ReadMemoryDword(addr2));
        bool b = itemname.contains(QRegExp("[\\x4e00-\\x9fa5]+"));
        QString Text;
        QString addlength = "1";
        if (b == true)
        {
            int length = itemname.toLocal8Bit().length();
            if (length == 10)
            {
                addlength = "                                               ";
            }
            else if (length == 8)
            {
                addlength = "                                                  ";
            }
            else if (length == 6)
            {
                addlength = "                                                     ";
            }
            else if (length == 4) {
                addlength = "                                                        ";
            }
            else if (length == 2) {
                addlength = "                                                          ";
            }
            else if (length == 9)
            {
                addlength = "                                                 ";
            }
            else if (length == 3)
            {
                addlength = "                                                            ";
            }
            else if (length == 5)
            {
                addlength = "                                                       ";
            }
            else if (length == 7)
            {
                addlength = "                                                       ";
            }
            else if (length == 12)
            {
                addlength = "                                             ";
            }
            else if (length == 13)
            {
                addlength = "                                            ";
            }
            else if (length == 14)
            {
                addlength = "                                           ";
            }
            else if (length == 15)
            {
                addlength = "                                          ";
            }
            else if (length == 16)
            {
                addlength = "                                         ";
            }
            else if (length == 17)
            {
                addlength = "                                        ";
            }
            else if (length == 21)
            {
                addlength = "                                    ";
            }
            else if (length == 11)
            {
                addlength = "                                             ";
            }
            else if (length == 18)
            {
                addlength = "                                      ";
            }


            ui.ItemLW->addItem(itemID + addlength + itemname);
            Text = itemID + addlength + itemname;
            str = str + Text + "\n";
          



            //qDebug()<<itemname;
        }

    }
    if (ui.Itemcheck->isChecked() == true)
    {

        QFile file(QStandardPaths::writableLocation(QStandardPaths::DesktopLocation) + "/Item.txt");
        file.open(QIODevice::ReadWrite | QIODevice::Text);
        file.write(str.toUtf8());
        file.close();

    }

    ui.pushButton_8->hide();
    return 0;
}

void ReadText::ShowCreature(bool checked)
{
    QString number = ui.BiologyLine->text();
    int value = number.toInt();
    QString str = "";

    for (int i = 1; i <= value; i++)
    {




        DWORD addr = Memory.Linked_Integer3(Biologyaddr, 8, i * 4 - 4, 0x10);
        DWORD addr2 = Memory.Linked_Integer3(Biologyaddr, 8, i * 4 - 4, 0);
        QString Biologyname = Memory.ReadMemoryString(addr);
        int BiologyID_int = Memory.ReadMemoryDword(addr2);
        QString BiologyID = QString::number(Memory.ReadMemoryDword(addr2));
        bool b = Biologyname.contains(QRegExp("[\\x4e00-\\x9fa5]+")); //�ж��Ƿ�������
        QString Text;

        QString addlength = "1";
        if (b == true && BiologyID_int >= 3000)
        {
            int length = Biologyname.toLocal8Bit().length();
            if (length == 10)
            {
                addlength = "                                               ";
            }
            else if (length == 8)
            {
                addlength = "                                                  ";
            }
            else if (length == 6)
            {
                addlength = "                                                     ";
            }
            else if (length == 4) {
                addlength = "                                                        ";
            }
            else if (length == 2) {
                addlength = "                                                           ";
            }
            else if (length == 9)
            {
                addlength = "                                                ";
            }
            else if (length == 7)
            {
                addlength = "                                                    ";
            }
            else if (length == 3) {
                addlength = "                                                         ";
            }
            ui.BiologyLW->addItem(BiologyID + addlength + Biologyname);
            Text = BiologyID + addlength + Biologyname;
            str = str + Text + "\n";


            //qDebug()<<itemname;
        }

    }
    if (ui.Creaturecheck->isChecked() == true)
    {

        QFile file(QStandardPaths::writableLocation(QStandardPaths::DesktopLocation) + "/Creature.txt");
        file.open(QIODevice::ReadWrite | QIODevice::Text);
        file.write(str.toUtf8());
        file.close();

    }

    ui.pushButton_9->hide();

    ui.BiologyLW->sortItems();
    
}

void ReadText::ShowSkin(bool checked)
{
    QString number = ui.ModelLine->text();
    int value = number.toInt();
    QString str = "";

    for (int i = 0; i <= value; i++)
    {


        DWORD addr = Memory.Linked_Integer3(Modeladdr, 8, i * 4, 4);
        DWORD addr2 = Memory.Linked_Integer3(Modeladdr, 8, i * 4, 0);
        QString Modelname = Memory.ReadMemoryString(addr);
        QString ModelID = QString::number(Memory.ReadMemoryDword(addr2));
        bool b = Modelname.contains(QRegExp("[\\x4e00-\\x9fa5]+"));
        QString Text;

        QString addlength = "1";
        if (b == true && ModelID <= 1000)
        {
            int length = Modelname.toLocal8Bit().length();
            if (length == 10)
            {
                addlength = "                                               ";
            }
            else if (length == 8)
            {
                addlength = "                                                  ";
            }
            else if (length == 6)
            {
                addlength = "                                                     ";
            }
            else if (length == 4) {
                addlength = "                                                        ";
            }
            else if (length == 2) {
                addlength = "                                                           ";
            }
            else if (length == 9)
            {
                addlength = "                                                ";
            }
            else if (length == 7)
            {
                addlength = "                                                    ";
            }
            else if (length == 12)
            {
                addlength = "                                             ";
            }
            else if (length == 13)
            {
                addlength = "                                            ";
            }
            else if (length == 14)
            {
                addlength = "                                           ";
            }
            else if (length == 15)
            {
                addlength = "                                          ";
            }
            else if (length == 16)
            {
                addlength = "                                         ";
            }
            else if (length == 17)
            {
                addlength = "                                        ";
            }
            else if (length == 21)
            {
                addlength = "                                    ";
            }
            else if (length == 18)
            {
                addlength = "                                      ";
            }
            else if (length == 19)
            {
                addlength = "                                    ";
            }
            else if (length == 11)
            {
                addlength = "                                               ";
            }
            ui.ModelLW->addItem(ModelID + addlength + Modelname);
            Text = ModelID + addlength + Modelname;
            str = str+Text+"\n";
            
            //qDebug()<<itemname;
        }
    }
    //           if(i-12==0){//�趨�ӳ�ˢ��
    //               QTime reachtime = QTime::currentTime().addMSecs(100);//�����100�������һ��ˢ�£�ÿ��ˢ��12����ˢ��֮��i���㡣
    //               while(QTime::currentTime()<reachtime){
    //                   QCoreApplication::processEvents(QEventLoop::AllEvents,100);
    //               }
    //               i=0;
    //           }
    //           i++;
    if (ui.flycheck->isChecked()==true)
    {
        
        QFile file(QStandardPaths::writableLocation(QStandardPaths::DesktopLocation)+"/Skin.txt");
        file.open(QIODevice::ReadWrite | QIODevice::Text);
        file.write(str.toUtf8());
        file.close();

    }
    ui.pushButton_10->hide();

}
void ReadText::ShowThrow(bool checked)
{
    QString number = ui.ThrowLine->text();
    int value = number.toInt();
    QString str = "";
    for (int i = 0; i <= value; i++)
    {


        DWORD addr = Memory.Linked_Integer3(ThrowAddr, 8, i * 4, 4);
        DWORD addr2 = Memory.Linked_Integer3(ThrowAddr, 8, i * 4, 0);
        QString Throwname = Memory.ReadMemoryString(addr);
        QString ThrowID = QString::number(Memory.ReadMemoryDword(addr2));
        bool b = Throwname.contains(QRegExp("[\\x4e00-\\x9fa5]+"));
        QString Text;

        QString addlength = "1";
        if (b == true)
        {
            int length = Throwname.toLocal8Bit().length();
            if (length == 10)
            {
                addlength = "                                               ";
            }
            else if (length == 8)
            {
                addlength = "                                                  ";
            }
            else if (length == 6)
            {
                addlength = "                                                     ";
            }
            else if (length == 4) {
                addlength = "                                                        ";
            }
            else if (length == 2) {
                addlength = "                                                           ";
            }
            else if (length == 9)
            {
                addlength = "                                                ";
            }
            else if (length == 7)
            {
                addlength = "                                                    ";
            }
            else if (length == 12)
            {
                addlength = "                                             ";
            }
            else if (length == 13)
            {
                addlength = "                                            ";
            }
            else if (length == 14)
            {
                addlength = "                                           ";
            }
            else if (length == 15)
            {
                addlength = "                                          ";
            }
            else if (length == 16)
            {
                addlength = "                                         ";
            }
            else if (length == 17)
            {
                addlength = "                                        ";
            }
            else if (length == 21)
            {
                addlength = "                                    ";
            }
            else if (length == 18)
            {
                addlength = "                                      ";
            }
            else if (length == 19)
            {
                addlength = "                                    ";
            }
            else if (length == 11)
            {
                addlength = "                                               ";
            }
            else if (length == 27)
            {
                addlength = "                       ";
            }
            else if (length == 31)
            {
                addlength = "               ";
            }
            else if (length == 28)
            {
                addlength = "                     ";
            }
            else if (length == 29)
            {
                addlength = "                   ";
            }
            else if (length == 26)
            {
                addlength = "                         ";
            }
            else if (length == 25)
            {
                addlength = "                           ";
            }
            else if (length == 24)
            {
                addlength = "                             ";
            }
            else if (length == 23)
            {
                addlength = "                               ";
            }
            else if (length == 22)
            {
                addlength = "                                 ";
            }
            else if (length == 20)
            {
                addlength = "                                      ";
            }
            else if (length == 36)
            {
                addlength = "               ";
            }
            else if (length == 37)
            {
                addlength = "                 ";
            }
            else if (length == 32)
            {
                addlength = "              ";
            }
            ui.ThrowLW->addItem(ThrowID + addlength + Throwname);
            Text = ThrowID + addlength + Throwname;
            str = str + Text + "\n";
            //qDebug()<<itemname;
        }
    }
    //           if(i-12==0){//�趨�ӳ�ˢ��
    //               QTime reachtime = QTime::currentTime().addMSecs(100);//�����100�������һ��ˢ�£�ÿ��ˢ��12����ˢ��֮��i���㡣
    //               while(QTime::currentTime()<reachtime){
    //                   QCoreApplication::processEvents(QEventLoop::AllEvents,100);
    //               }
    //               i=0;
    //           }
    //           i++;
    if (ui.Throwcheck->isChecked() == true)
    {

        QFile file(QStandardPaths::writableLocation(QStandardPaths::DesktopLocation) + "/Throw.txt");
        file.open(QIODevice::ReadWrite | QIODevice::Text);
        file.write(str.toUtf8());
        file.close();

    }
    ui.pushButton_11->hide();
    ui.ThrowLW->sortItems();

}