#include "MyData.h"
#include<stdio.h>
#include<Windows.h>
#pragma once
BOOL UnicodeToAnsi(PCHAR szTartget, PWCHAR szSrc, DWORD size)
{
    if (szTartget == 0 || szSrc == 0)
    {
        return FALSE;
    }
    int i = 0;
    while (*szSrc != 0 && i < 256)
    {
        *szTartget = *szSrc;
        szTartget++;
        szSrc++;
        i++;
    }
    return TRUE;
}