#pragma once
#define _USE_MATH_DEFINES

#include<Windows.h>
#include <iostream>
#include <TlHelp32.h>
#include <QString>
#include <string>
#include <vector>
//#include <atlconv.h>

using namespace std;
namespace Function {

    std::vector<DWORD> SearchMemory(HANDLE hProcess, char* Pattern, DWORD StartAddress, DWORD EndAddress);
}
class memory
{
private:
    HANDLE m_hpro;
private:
    DWORD GetProcessIdForWindow(const char* clsName, const char* winName);
public:
    void InitProcessHandleForWindow(const char* clsName, const char* winName);
    HANDLE GetProcessHandle();
    void SetProcessHandle(HANDLE hpro);
    DWORD GetModuleAddress(char* szName);
    int Linked_Integer(int address, const int Deviation1);
    int Linked_Integer2(int address, const int Deviation1, const int Deviation2);
    int Linked_Integer3(int address, const int Deviation1, const int Deviation2, const int Deviation3);


    DWORD GetAddress(char* Pattern, DWORD Module, DWORD Off);
    QString GetFreeAddress(DWORD address);
    /*template<typename datatype>
    datatype ReadMemory(DWORD addr)
    {
        datatype data;
        ReadProcessMemory(m_hpro, addr, &data, sizeof(datatype), NULL);
        return data;
    }*/
    int WriteProcessMemoryint(int Pid, long Base, int WriteValue)
    {
        DWORD byread;
        int Value = 0;
        HANDLE proce = ::OpenProcess(PROCESS_ALL_ACCESS, false, Pid);
        LPCVOID pbase = (LPCVOID)Base;
        LPVOID rbuffer = (LPVOID)&Value;

        /*::ReadProcessMemory(proce, pbase, rbuffer, 4, &byread);
        pbase = (LPCVOID)(Value+one);

        ::ReadProcessMemory(proce, pbase, rbuffer, 4, &byread);
        pbase = (LPCVOID)(Value + two);*/

        ::ReadProcessMemory(proce, pbase, rbuffer, 4, &byread);


        DWORD bywrite;
        LPVOID wbuffer = (LPVOID)&WriteValue;
        WriteProcessMemory(proce, (LPVOID)pbase, wbuffer, 4, &bywrite);

        return 1;

    }


    QString ReadMemoryString(DWORD addr)
    {
        char data[48];
        ReadProcessMemory(m_hpro, (LPVOID)addr, &data, 48, NULL);
        return (QString)data;
    }

    BYTE ReadMemoryByte(DWORD addr)
    {
        BYTE data;
        ReadProcessMemory(m_hpro, (LPVOID)addr, &data, 1, NULL);
        return data;
    }

    int ReadMemoryDword(DWORD addr)
    {
        int data;
        ReadProcessMemory(m_hpro, (void*)addr, &data, sizeof(data), NULL);
        return data;
    }

    float ReadMemoryFloat(DWORD addr)
    {
        float data;
        ReadProcessMemory(m_hpro, (void*)addr, &data, sizeof(data), NULL);
        return data;
    }

    double ReadMemoryDouble(DWORD addr)
    {
        double data;
        ReadProcessMemory(m_hpro, (void*)addr, &data, sizeof(data), NULL);
        return data;
    }

    template <typename Type>
    Type ReadMemory(DWORD Address)
    {
        Type Temp;
        if (!ReadProcessMemory(m_hpro, reinterpret_cast<LPCVOID>(Address), &Temp, sizeof(Type), 0))
            return Type{};
        return Temp;
    }


    int GetwindowW(HWND hwnd)
    {
        RECT rect;
        GetWindowRect(hwnd, &rect);
        return rect.right - rect.left;
    }

    int GetwindowH(HWND hwnd)
    {
        RECT rect;
        GetWindowRect(hwnd, &rect);
        return rect.bottom - rect.top;
    }


};



//namespace Function {
//	HMODULE GetProcessModuleHandle(DWORD pid, const char* ModuleName);
//	int GetProcessID(const char* ProcessName);
//
//	template <typename T>
//	T ReadMemory(HANDLE hProcess, DWORD Address)
//	{
//		T temp;
//		if (ReadProcessMemory(hProcess, (LPCVOID)Address, &temp, sizeof(T), 0))
//
//			return temp;
//		return NULL;
//	}
//}
