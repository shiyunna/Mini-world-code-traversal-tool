/********************************************************************************
** Form generated from reading UI file 'ReadText.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_READTEXT_H
#define UI_READTEXT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ReadTextClass
{
public:
    QLabel *label_2;
    QPushButton *close_btn;
    QLabel *label;
    QTabWidget *tabWidget;
    QWidget *tab;
    QListWidget *ItemLW;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_9;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_13;
    QPushButton *pushButton_8;
    QLabel *label_21;
    QLineEdit *ItemLine;
    QCheckBox *Itemcheck;
    QWidget *tab_3;
    QLabel *label_7;
    QListWidget *ModelLW;
    QLabel *label_8;
    QPushButton *pushButton_10;
    QLabel *label_17;
    QLabel *label_18;
    QLineEdit *ModelLine;
    QLabel *label_19;
    QCheckBox *flycheck;
    QWidget *tab_2;
    QListWidget *BiologyLW;
    QLabel *label_5;
    QLabel *label_6;
    QPushButton *pushButton_9;
    QLabel *label_20;
    QLineEdit *BiologyLine;
    QCheckBox *Creaturecheck;
    QWidget *tab_4;
    QLineEdit *ThrowLine;
    QListWidget *ThrowLW;
    QLabel *label_23;
    QLabel *label_24;
    QPushButton *pushButton_11;
    QLabel *label_25;
    QCheckBox *Throwcheck;
    QLabel *label_22;

    void setupUi(QWidget *ReadTextClass)
    {
        if (ReadTextClass->objectName().isEmpty())
            ReadTextClass->setObjectName(QString::fromUtf8("ReadTextClass"));
        ReadTextClass->resize(541, 401);
        ReadTextClass->setStyleSheet(QString::fromUtf8("QLabel#label{\n"
"	image: url(:/ReadText/ico.ico);\n"
"	font: 75 9pt \"\347\255\211\347\272\277\";\n"
"\n"
"\n"
"}\n"
"QLabel#label_2{\n"
"background-color: rgb(242,242,242);\n"
"border-radius: 10px;\n"
"\n"
"}\n"
"QLabel#label_22{\n"
"font: 75 10pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"}\n"
"QCheckBox{\n"
"font:normal 15px \"\345\215\216\345\272\267\346\226\271\345\234\206\344\275\223\";\n"
"}\n"
"\n"
"QPushButton#close_btn\n"
"{\n"
"border-image: url(:/ReadText/close2.png);\n"
"}\n"
"QPushButton#close_btn{\n"
"width:120px;\n"
"height:120px;\n"
"}\n"
"QListWidget\n"
"{\n"
"background-color: rgb(252, 252, 252);\n"
"transparent;border:1px solid rgb(238, 238, 238);\n"
"\n"
"\n"
"}\n"
"\n"
"QTabWidget::pane {\n"
"border-top: 1px solid #E5E5E5;\n"
"border-left:1px solid #E5E5E5;\n"
"position: absolute;\n"
"font-size: 14px;\n"
"background-color:#FFFFFF;\n"
"}\n"
" \n"
"\n"
"QTabBar::tab {\n"
"border: none;\n"
"border-bottom-color: #FFFFFF; /* same as the pane color */\n"
"border-top-left-radius:"
                        " 4px;\n"
"border-top-right-radius: 4px;\n"
"min-width: 8ex;\n"
"padding: 2px;\n"
"font-size: 14px;\n"
"background-color:#FFFFFF;\n"
"}\n"
"QTabBar::tab:selected, QTabBar::tab:hover {\n"
"background-color:#FFFFFF;/*\351\200\211\344\270\255\350\203\214\346\231\257\350\211\262*/\n"
"}\n"
"QTabBar::tab:selected {\n"
"color:#2080F7;\n"
"border-bottom: 2px solid #2080F7;\n"
"font-weight:bold;\n"
"background-color:#FFFFFF;\n"
"}\n"
" \n"
"\n"
"QTabWidget::tab-bar {\n"
"border-top: 2px solid #E5E5E5;\n"
"border-bottom: 2px solid #E5E5E5;\n"
"border-left:1px solid #E5E5E5;\n"
"\n"
"font-size: 14px;\n"
"background-color:#FFFFFF;\n"
"\n"
"}\n"
"QTabBar::tab{\n"
"	font: 75 12pt \"Arial\";	\n"
"	width:84px;				\n"
"	height:30; 				\n"
"	margin-top:5px; 		\n"
"	margin-right:1px;\n"
"	margin-left:1px;\n"
"	margin-bottom:0px;\n"
"}\n"
"QPushButton#pushButton\n"
"{\n"
"background-color: rgb(255, 255, 255);\n"
"transparent;border:1px solid rgb(255, 255, 255);\n"
"\n"
"}\n"
"QPushButton#pushButton_2\n"
"{\n"
"background-color: r"
                        "gb(255, 255, 255);\n"
"transparent;border:1px solid rgb(255, 255, 255);\n"
"\n"
"}\n"
"\n"
"QPushButton#pushButton_3\n"
"{\n"
"background-color: rgb(255, 255, 255);\n"
"transparent;border:1px solid rgb(255, 255, 255);\n"
"\n"
"}\n"
"QPushButton#pushButton_4\n"
"{\n"
"background-color: rgb(255, 255, 255);\n"
"transparent;border:1px solid rgb(255, 255, 255);\n"
"\n"
"}\n"
"QPushButton#pushButton_5\n"
"{\n"
"background-color: rgb(255, 255, 255);\n"
"transparent;border:1px solid rgb(255, 255, 255);\n"
"\n"
"}\n"
"QPushButton#pushButton_6\n"
"{\n"
"background-color: rgb(255, 255, 255);\n"
"transparent;border:1px solid rgb(255, 255, 255);\n"
"\n"
"}\n"
"QPushButton#pushButton_7\n"
"{\n"
"background-color: rgb(255, 255, 255);\n"
"transparent;border:1px solid rgb(255, 255, 255);\n"
"\n"
"}\n"
"QPushButton#pushButton_8\n"
"{\n"
"border:2px groove gray;border-radius:4px;padding:2px 4px;\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(28, 151, 242);\n"
"transparent;border:1px solid rgb(28, 151, 242);\n"
"	font: "
                        "11pt \"Arial\";\n"
"\n"
"}\n"
"QPushButton#pushButton_9\n"
"{\n"
"border:2px groove gray;border-radius:4px;padding:2px 4px;\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(28, 151, 242);\n"
"transparent;border:1px solid rgb(28, 151, 242);\n"
"	font: 11pt \"Arial\";\n"
"\n"
"}\n"
"QPushButton#pushButton_10\n"
"{\n"
"border:2px groove gray;border-radius:4px;padding:2px 4px;\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(28, 151, 242);\n"
"transparent;border:1px solid rgb(28, 151, 242);\n"
"	font: 11pt \"Arial\";\n"
"\n"
"}\n"
"QPushButton#pushButton_11\n"
"{\n"
"border:2px groove gray;border-radius:4px;padding:2px 4px;\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(28, 151, 242);\n"
"transparent;border:1px solid rgb(28, 151, 242);\n"
"	font: 11pt \"Arial\";\n"
"\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"QPushButton#pushButton:hover{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton:pressed{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"\n"
"QPushButton#pushButton_2:hover{\n"
"	color: rg"
                        "b(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton_2:pressed{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton_3:hover{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton_3:pressed{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton_4:hover{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton_4:pressed{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton_5:hover{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton_5:pressed{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton_6:hover{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton_6:pressed{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton_7:hover{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"QPushButton#pushButton_7:pressed{\n"
"	color: rgb(30, 159, 255);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QLabel#label_10\n"
"{\n"
"color: rgb(238, 238, 238);\n"
"}\n"
"QLabel#label_11\n"
"{\n"
"color: rgb(238, 238, 238);\n"
"}\n"
"QL"
                        "abel#label_12\n"
"{\n"
"color: rgb(238, 238, 238);\n"
"}\n"
"QLabel#label_13\n"
"{\n"
"color: rgb(238, 238, 238);\n"
"}\n"
"QLabel#label_14\n"
"{\n"
"color: rgb(238, 238, 238);\n"
"}\n"
"QLabel#label_15\n"
"{\n"
"color: rgb(238, 238, 238);\n"
"}\n"
"QLabel#label_16\n"
"{\n"
"color: rgb(238, 238, 238);\n"
"}\n"
"Qlabel\n"
"{\n"
"border-radius: 8px;\n"
"}\n"
"\n"
""));
        label_2 = new QLabel(ReadTextClass);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(0, 0, 541, 401));
        close_btn = new QPushButton(ReadTextClass);
        close_btn->setObjectName(QString::fromUtf8("close_btn"));
        close_btn->setGeometry(QRect(500, 0, 35, 35));
        label = new QLabel(ReadTextClass);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 31, 21));
        tabWidget = new QTabWidget(ReadTextClass);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(20, 30, 491, 331));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        ItemLW = new QListWidget(tab);
        ItemLW->setObjectName(QString::fromUtf8("ItemLW"));
        ItemLW->setGeometry(QRect(110, 40, 361, 211));
        label_3 = new QLabel(tab);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(120, 20, 51, 20));
        label_4 = new QLabel(tab);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(210, 20, 51, 20));
        label_9 = new QLabel(tab);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(290, 20, 51, 20));
        pushButton = new QPushButton(tab);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(20, 40, 80, 20));
        pushButton_2 = new QPushButton(tab);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(20, 70, 80, 20));
        pushButton_3 = new QPushButton(tab);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(20, 220, 80, 20));
        pushButton_4 = new QPushButton(tab);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(20, 190, 80, 20));
        pushButton_5 = new QPushButton(tab);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(20, 160, 80, 20));
        pushButton_6 = new QPushButton(tab);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(20, 130, 80, 20));
        pushButton_7 = new QPushButton(tab);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(20, 100, 80, 20));
        label_10 = new QLabel(tab);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(20, 60, 81, 16));
        label_11 = new QLabel(tab);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(20, 90, 81, 16));
        label_12 = new QLabel(tab);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(20, 210, 81, 16));
        label_14 = new QLabel(tab);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(20, 150, 81, 16));
        label_15 = new QLabel(tab);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(20, 180, 81, 16));
        label_16 = new QLabel(tab);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(20, 120, 81, 16));
        label_13 = new QLabel(tab);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(20, 240, 81, 16));
        pushButton_8 = new QPushButton(tab);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(170, 120, 211, 36));
        pushButton_8->setCursor(QCursor(Qt::OpenHandCursor));
        label_21 = new QLabel(tab);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(310, 260, 51, 20));
        ItemLine = new QLineEdit(tab);
        ItemLine->setObjectName(QString::fromUtf8("ItemLine"));
        ItemLine->setGeometry(QRect(370, 260, 113, 21));
        Itemcheck = new QCheckBox(tab);
        Itemcheck->setObjectName(QString::fromUtf8("Itemcheck"));
        Itemcheck->setGeometry(QRect(10, 260, 131, 21));
        Itemcheck->setStyleSheet(QString::fromUtf8(""));
        Itemcheck->setChecked(true);
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        label_7 = new QLabel(tab_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(60, 20, 51, 20));
        ModelLW = new QListWidget(tab_3);
        ModelLW->setObjectName(QString::fromUtf8("ModelLW"));
        ModelLW->setGeometry(QRect(30, 40, 421, 211));
        label_8 = new QLabel(tab_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(110, 20, 41, 20));
        pushButton_10 = new QPushButton(tab_3);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setGeometry(QRect(140, 120, 211, 36));
        pushButton_10->setCursor(QCursor(Qt::OpenHandCursor));
        label_17 = new QLabel(tab_3);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(270, 20, 51, 20));
        label_18 = new QLabel(tab_3);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(180, 20, 61, 20));
        ModelLine = new QLineEdit(tab_3);
        ModelLine->setObjectName(QString::fromUtf8("ModelLine"));
        ModelLine->setGeometry(QRect(370, 260, 113, 21));
        label_19 = new QLabel(tab_3);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(310, 260, 51, 20));
        flycheck = new QCheckBox(tab_3);
        flycheck->setObjectName(QString::fromUtf8("flycheck"));
        flycheck->setGeometry(QRect(10, 260, 131, 21));
        flycheck->setStyleSheet(QString::fromUtf8(""));
        flycheck->setChecked(false);
        tabWidget->addTab(tab_3, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        BiologyLW = new QListWidget(tab_2);
        BiologyLW->setObjectName(QString::fromUtf8("BiologyLW"));
        BiologyLW->setGeometry(QRect(30, 40, 421, 211));
        label_5 = new QLabel(tab_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(280, 20, 51, 20));
        label_6 = new QLabel(tab_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(60, 20, 41, 20));
        pushButton_9 = new QPushButton(tab_2);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(140, 120, 211, 36));
        pushButton_9->setCursor(QCursor(Qt::OpenHandCursor));
        label_20 = new QLabel(tab_2);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(310, 260, 51, 20));
        BiologyLine = new QLineEdit(tab_2);
        BiologyLine->setObjectName(QString::fromUtf8("BiologyLine"));
        BiologyLine->setGeometry(QRect(370, 260, 113, 21));
        Creaturecheck = new QCheckBox(tab_2);
        Creaturecheck->setObjectName(QString::fromUtf8("Creaturecheck"));
        Creaturecheck->setGeometry(QRect(10, 260, 131, 21));
        Creaturecheck->setStyleSheet(QString::fromUtf8(""));
        Creaturecheck->setChecked(false);
        tabWidget->addTab(tab_2, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        ThrowLine = new QLineEdit(tab_4);
        ThrowLine->setObjectName(QString::fromUtf8("ThrowLine"));
        ThrowLine->setGeometry(QRect(370, 260, 113, 21));
        ThrowLW = new QListWidget(tab_4);
        ThrowLW->setObjectName(QString::fromUtf8("ThrowLW"));
        ThrowLW->setGeometry(QRect(30, 40, 421, 211));
        label_23 = new QLabel(tab_4);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(270, 20, 61, 20));
        label_24 = new QLabel(tab_4);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setGeometry(QRect(310, 260, 51, 20));
        pushButton_11 = new QPushButton(tab_4);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setGeometry(QRect(140, 120, 211, 36));
        pushButton_11->setCursor(QCursor(Qt::OpenHandCursor));
        label_25 = new QLabel(tab_4);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(60, 20, 51, 20));
        Throwcheck = new QCheckBox(tab_4);
        Throwcheck->setObjectName(QString::fromUtf8("Throwcheck"));
        Throwcheck->setGeometry(QRect(10, 260, 131, 21));
        Throwcheck->setStyleSheet(QString::fromUtf8(""));
        Throwcheck->setChecked(false);
        tabWidget->addTab(tab_4, QString());
        label_22 = new QLabel(ReadTextClass);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(30, 0, 251, 21));

        retranslateUi(ReadTextClass);
        QObject::connect(close_btn, SIGNAL(clicked()), ReadTextClass, SLOT(close()));

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(ReadTextClass);
    } // setupUi

    void retranslateUi(QWidget *ReadTextClass)
    {
        ReadTextClass->setWindowTitle(QCoreApplication::translate("ReadTextClass", "ReadText", nullptr));
        label_2->setText(QString());
        close_btn->setText(QString());
        label->setText(QString());
        label_3->setText(QCoreApplication::translate("ReadTextClass", "\347\211\251\345\223\201ID", nullptr));
        label_4->setText(QCoreApplication::translate("ReadTextClass", "\347\211\251\345\223\201\347\261\273\345\236\213", nullptr));
        label_9->setText(QCoreApplication::translate("ReadTextClass", "\347\211\251\345\223\201\346\230\265\347\247\260", nullptr));
        pushButton->setText(QCoreApplication::translate("ReadTextClass", "\345\205\250\351\203\250", nullptr));
        pushButton_2->setText(QCoreApplication::translate("ReadTextClass", "\344\275\234\347\211\251", nullptr));
        pushButton_3->setText(QCoreApplication::translate("ReadTextClass", "\345\205\266\344\273\226", nullptr));
        pushButton_4->setText(QCoreApplication::translate("ReadTextClass", "\345\274\200\345\217\221\350\200\205", nullptr));
        pushButton_5->setText(QCoreApplication::translate("ReadTextClass", "\346\226\271\345\235\227", nullptr));
        pushButton_6->setText(QCoreApplication::translate("ReadTextClass", "\346\235\202\347\211\251", nullptr));
        pushButton_7->setText(QCoreApplication::translate("ReadTextClass", "\345\267\245\345\205\267", nullptr));
        label_10->setText(QCoreApplication::translate("ReadTextClass", "-------------", nullptr));
        label_11->setText(QCoreApplication::translate("ReadTextClass", "-------------", nullptr));
        label_12->setText(QCoreApplication::translate("ReadTextClass", "-------------", nullptr));
        label_14->setText(QCoreApplication::translate("ReadTextClass", "-------------", nullptr));
        label_15->setText(QCoreApplication::translate("ReadTextClass", "-------------", nullptr));
        label_16->setText(QCoreApplication::translate("ReadTextClass", "-------------", nullptr));
        label_13->setText(QCoreApplication::translate("ReadTextClass", "-------------", nullptr));
        pushButton_8->setText(QCoreApplication::translate("ReadTextClass", "\347\202\271\345\207\273\344\273\216\345\206\205\345\255\230\344\270\255\351\201\215\345\216\206\345\207\272\347\211\251\345\223\201ID", nullptr));
        label_21->setText(QCoreApplication::translate("ReadTextClass", "\351\201\215\345\216\206\346\254\241\346\225\260:", nullptr));
        ItemLine->setText(QCoreApplication::translate("ReadTextClass", "10000", nullptr));
        Itemcheck->setText(QCoreApplication::translate("ReadTextClass", "\346\230\257\345\220\246\344\277\235\345\255\230\345\210\260\346\241\214\351\235\242", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("ReadTextClass", "\347\211\251\345\223\201ID", nullptr));
        label_7->setText(QCoreApplication::translate("ReadTextClass", "\347\232\256\350\202\244ID", nullptr));
        label_8->setText(QCoreApplication::translate("ReadTextClass", "\346\250\241\345\236\213ID", nullptr));
        pushButton_10->setText(QCoreApplication::translate("ReadTextClass", "\347\202\271\345\207\273\344\273\216\345\206\205\345\255\230\344\270\255\351\201\215\345\216\206\345\207\272\347\224\237\347\211\251ID", nullptr));
        label_17->setText(QCoreApplication::translate("ReadTextClass", "\347\232\256\350\202\244\346\230\265\347\247\260", nullptr));
        label_18->setText(QCoreApplication::translate("ReadTextClass", "\347\232\256\350\202\244\345\244\264\345\203\217ID", nullptr));
        ModelLine->setText(QCoreApplication::translate("ReadTextClass", "400", nullptr));
        label_19->setText(QCoreApplication::translate("ReadTextClass", "\351\201\215\345\216\206\346\254\241\346\225\260:", nullptr));
        flycheck->setText(QCoreApplication::translate("ReadTextClass", "\346\230\257\345\220\246\344\277\235\345\255\230\345\210\260\346\241\214\351\235\242", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("ReadTextClass", "\347\232\256\350\202\244ID", nullptr));
        label_5->setText(QCoreApplication::translate("ReadTextClass", "\347\224\237\347\211\251\345\220\215\347\247\260", nullptr));
        label_6->setText(QCoreApplication::translate("ReadTextClass", "\347\224\237\347\211\251ID", nullptr));
        pushButton_9->setText(QCoreApplication::translate("ReadTextClass", "\347\202\271\345\207\273\344\273\216\345\206\205\345\255\230\344\270\255\351\201\215\345\216\206\345\207\272\347\232\256\350\202\244ID", nullptr));
        label_20->setText(QCoreApplication::translate("ReadTextClass", "\351\201\215\345\216\206\346\254\241\346\225\260:", nullptr));
        BiologyLine->setText(QCoreApplication::translate("ReadTextClass", "1000", nullptr));
        Creaturecheck->setText(QCoreApplication::translate("ReadTextClass", "\346\230\257\345\220\246\344\277\235\345\255\230\345\210\260\346\241\214\351\235\242", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("ReadTextClass", "\347\224\237\347\211\251ID", nullptr));
        ThrowLine->setText(QCoreApplication::translate("ReadTextClass", "200", nullptr));
        label_23->setText(QCoreApplication::translate("ReadTextClass", "\346\212\225\346\216\267\347\211\251\345\220\215\347\247\260", nullptr));
        label_24->setText(QCoreApplication::translate("ReadTextClass", "\351\201\215\345\216\206\346\254\241\346\225\260:", nullptr));
        pushButton_11->setText(QCoreApplication::translate("ReadTextClass", "\347\202\271\345\207\273\344\273\216\345\206\205\345\255\230\344\270\255\351\201\215\345\216\206\345\207\272\347\232\256\350\202\244ID", nullptr));
        label_25->setText(QCoreApplication::translate("ReadTextClass", "\346\212\225\346\216\267\347\211\251ID", nullptr));
        Throwcheck->setText(QCoreApplication::translate("ReadTextClass", "\346\230\257\345\220\246\344\277\235\345\255\230\345\210\260\346\241\214\351\235\242", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QCoreApplication::translate("ReadTextClass", "\346\212\225\346\216\267\347\211\251ID", nullptr));
        label_22->setText(QCoreApplication::translate("ReadTextClass", "ShiYun---Learning text of QT", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ReadTextClass: public Ui_ReadTextClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_READTEXT_H
