#pragma once
#include<Windows.h>
BOOL UnicodeToAnsi(PCHAR szTartget, PWCHAR szSrc, DWORD size);

